
/*
 * Licensed Materials - Property of IBM
 *
 * trousers - An open source TCG Software Stack
 *
 * (C) Copyright International Business Machines Corp. 2007
 *
 */

#ifndef _TSP_SEAL_H_
#define _TSP_SEAL_H_

TSS_RESULT	sealx_mask_cb(UINT32, BYTE *, UINT32, BYTE *, BYTE *, UINT32, BYTE *, BYTE *);

#endif
