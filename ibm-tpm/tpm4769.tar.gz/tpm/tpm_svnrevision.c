const unsigned short tpm_svn_revision = 4768;
